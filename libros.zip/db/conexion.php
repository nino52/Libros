<?php
$host = 'localhost';
$db = 'u169081934_soynino52';
$user = 'u169081934_user';  // Cambia esto por el usuario de tu base de datos
$pass = 'Maria8293677049@';      // Cambia esto por la contraseña de tu base de datos
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Error en la conexión: " . $e->getMessage());
}
?>
