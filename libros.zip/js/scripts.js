// Añadir interactividad al formulario de contacto
document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.querySelector("form");
    formulario.addEventListener("submit", function (event) {
        const nombre = formulario.nombre.value.trim();
        const correo = formulario.correo.value.trim();
        const asunto = formulario.asunto.value.trim();
        const comentario = formulario.comentario.value.trim();

        // Validar que todos los campos estén completos
        if (!nombre || !correo || !asunto || !comentario) {
            event.preventDefault();
            alert("Por favor, completa todos los campos.");
        }
    });
});

// Añadir animaciones a los botones
document.querySelectorAll(".btn").forEach(button => {
    button.addEventListener("mouseover", () => {
        button.style.transform = "scale(1.1)";
        button.style.transition = "transform 0.3s ease"; // Añadí un "ease" para una animación más suave
    });
    button.addEventListener("mouseout", () => {
        button.style.transform = "scale(1)";
    });
});

// Mensaje de éxito tras enviar el formulario (si se ha enviado correctamente)
const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get("status") === "success") {
    setTimeout(() => { // Espera para dar tiempo a que el mensaje se vea
        alert("¡Gracias por tu mensaje! Nos pondremos en contacto contigo pronto.");
    }, 500); // 500ms de retraso para evitar conflictos visuales
}
