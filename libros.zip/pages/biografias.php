<?php
include '../templates/header.php';
include '../db/conexion.php';

// Consulta para obtener todas las biografías
$stmt = $pdo->query('SELECT b.id_autor, a.nombre, a.apellido, b.biografia 
                     FROM biografias b 
                     JOIN autores a ON b.id_autor = a.id_autor');
$biografias = $stmt->fetchAll();
?>
<div class="container mt-4">
    <h1 class="text-center">Biografías de Autores</h1>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID Autor</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Biografía</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($biografias as $bio): ?>
                <tr>
                    <td><?= htmlspecialchars($bio['id_autor']) ?></td>
                    <td><?= htmlspecialchars($bio['nombre']) ?></td>
                    <td><?= htmlspecialchars($bio['apellido']) ?></td>
                    <td><?= htmlspecialchars($bio['biografia']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include '../templates/footer.php'; ?>
