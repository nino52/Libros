<?php
include '../templates/header.php';
include '../db/conexion.php';

// Consulta para obtener libros junto con sus imágenes
$stmt = $pdo->query('
    SELECT t.id_titulo, t.titulo, t.precio, t.fecha_pub, f.fotografia 
    FROM titulos t
    LEFT JOIN fotografias f ON t.id_titulo = f.id_titulo
');
$libros = $stmt->fetchAll();
?>
<div class="container mt-4">
    <h1 class="text-center">Listado de Libros</h1>
    <div class="row">
        <?php foreach ($libros as $libro): ?>
        <div class="col-12 col-md-4 col-lg-4 mb-4">
            <div class="card">
                <!-- Verificar si hay una imagen para este libro y mostrarla, o usar una imagen predeterminada -->
                <?php 
                    // Corregir la ruta de la imagen para evitar duplicados de "assets/img"
                    $imagen = !empty($libro['fotografia']) ? '/assets/img/' . basename($libro['fotografia']) : '/assets/img/default.jpg';
                ?>
                <img src="<?= $imagen ?>" class="card-img-top" alt="<?= htmlspecialchars($libro['titulo']) ?>" style="height: 200px; width: 100%; object-fit: contain;">
                <div class="card-body">
                    <!-- Título, precio y fecha del libro -->
                    <h5 class="card-title"><?= htmlspecialchars($libro['titulo']) ?></h5>
                    <p class="card-text">Precio: $<?= htmlspecialchars($libro['precio']) ?></p>
                    <p class="card-text">Publicado el: <?= htmlspecialchars($libro['fecha_pub']) ?></p>

                    <!-- Botón Comprar -->
                    <div class="text-center">
                        <a href="https://www.amazon.com/b?node=283155" class="btn btn-success" target="_blank">Comprar</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include '../templates/footer.php'; ?>
