<?php
include '../templates/header.php';
include '../db/conexion.php';

$stmt = $pdo->query('SELECT * FROM autores');
$autores = $stmt->fetchAll();
?>
<div class="container mt-4">
    <h1 class="text-center">Listado de Autores</h1>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($autores as $autor): ?>
                <tr>
                    <td><?= htmlspecialchars($autor['id_autor']) ?></td>
                    <td><?= htmlspecialchars($autor['nombre']) ?></td>
                    <td><?= htmlspecialchars($autor['apellido']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include '../templates/footer.php'; ?>
